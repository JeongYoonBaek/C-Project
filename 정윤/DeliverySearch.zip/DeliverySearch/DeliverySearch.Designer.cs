﻿namespace C_TeamProject
{
    partial class Delivery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Delivery));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.검색 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.개인정보수정 = new System.Windows.Forms.Button();
            this.받는분 = new System.Windows.Forms.Label();
            this.주소 = new System.Windows.Forms.Label();
            this.약품명 = new System.Windows.Forms.Label();
            this.결제일 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.배송상태 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.타이틀 = new System.Windows.Forms.Button();
            this.배송정보수정 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label5.Location = new System.Drawing.Point(30, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 48);
            this.label5.TabIndex = 14;
            this.label5.Text = "QMS";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::C_TeamProject.Properties.Resources.free_icon_retouch_6344556;
            this.pictureBox3.InitialImage = global::C_TeamProject.Properties.Resources.free_icon_retouch_6344556;
            this.pictureBox3.Location = new System.Drawing.Point(30, 350);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 40);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, 250);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // 검색
            // 
            this.검색.BackColor = System.Drawing.Color.Transparent;
            this.검색.FlatAppearance.BorderSize = 0;
            this.검색.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.검색.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.검색.Location = new System.Drawing.Point(60, 250);
            this.검색.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.검색.Name = "검색";
            this.검색.Size = new System.Drawing.Size(130, 40);
            this.검색.TabIndex = 16;
            this.검색.Text = "Search";
            this.검색.UseVisualStyleBackColor = false;
            this.검색.Click += new System.EventHandler(this.검색_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MistyRose;
            this.button3.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(855, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 30);
            this.button3.TabIndex = 24;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(30, 300);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 40);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 28;
            this.pictureBox5.TabStop = false;
            // 
            // 개인정보수정
            // 
            this.개인정보수정.BackColor = System.Drawing.Color.Transparent;
            this.개인정보수정.FlatAppearance.BorderSize = 0;
            this.개인정보수정.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.개인정보수정.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.개인정보수정.Location = new System.Drawing.Point(60, 300);
            this.개인정보수정.Name = "개인정보수정";
            this.개인정보수정.Size = new System.Drawing.Size(130, 40);
            this.개인정보수정.TabIndex = 27;
            this.개인정보수정.Text = "MyInfo Update ";
            this.개인정보수정.UseVisualStyleBackColor = false;
            this.개인정보수정.Click += new System.EventHandler(this.개인정보수정_Click);
            // 
            // 받는분
            // 
            this.받는분.AutoSize = true;
            this.받는분.BackColor = System.Drawing.Color.Transparent;
            this.받는분.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.받는분.Location = new System.Drawing.Point(300, 210);
            this.받는분.Name = "받는분";
            this.받는분.Size = new System.Drawing.Size(46, 13);
            this.받는분.TabIndex = 29;
            this.받는분.Text = "받는분";
            // 
            // 주소
            // 
            this.주소.AutoSize = true;
            this.주소.BackColor = System.Drawing.Color.Transparent;
            this.주소.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.주소.Location = new System.Drawing.Point(300, 250);
            this.주소.Name = "주소";
            this.주소.Size = new System.Drawing.Size(33, 13);
            this.주소.TabIndex = 30;
            this.주소.Text = "주소";
            // 
            // 약품명
            // 
            this.약품명.AutoSize = true;
            this.약품명.BackColor = System.Drawing.Color.Transparent;
            this.약품명.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.약품명.Location = new System.Drawing.Point(300, 290);
            this.약품명.Name = "약품명";
            this.약품명.Size = new System.Drawing.Size(46, 13);
            this.약품명.TabIndex = 31;
            this.약품명.Text = "약품명";
            // 
            // 결제일
            // 
            this.결제일.AutoSize = true;
            this.결제일.BackColor = System.Drawing.Color.Transparent;
            this.결제일.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.결제일.Location = new System.Drawing.Point(300, 330);
            this.결제일.Name = "결제일";
            this.결제일.Size = new System.Drawing.Size(46, 13);
            this.결제일.TabIndex = 32;
            this.결제일.Text = "결제일";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(380, 205);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 21);
            this.textBox1.TabIndex = 33;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(380, 245);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 21);
            this.textBox2.TabIndex = 34;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(380, 285);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 21);
            this.textBox3.TabIndex = 35;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(380, 325);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(200, 21);
            this.textBox4.TabIndex = 36;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::C_TeamProject.Properties.Resources._201608240940105432_t;
            this.pictureBox6.Location = new System.Drawing.Point(0, 459);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(900, 160);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 37;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // 배송상태
            // 
            this.배송상태.AutoSize = true;
            this.배송상태.BackColor = System.Drawing.Color.Transparent;
            this.배송상태.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.배송상태.Location = new System.Drawing.Point(300, 370);
            this.배송상태.Name = "배송상태";
            this.배송상태.Size = new System.Drawing.Size(59, 13);
            this.배송상태.TabIndex = 38;
            this.배송상태.Text = "배송상태";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(380, 365);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(200, 21);
            this.textBox5.TabIndex = 39;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(30, 200);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // 타이틀
            // 
            this.타이틀.BackColor = System.Drawing.Color.Transparent;
            this.타이틀.FlatAppearance.BorderSize = 0;
            this.타이틀.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.타이틀.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.타이틀.Location = new System.Drawing.Point(60, 200);
            this.타이틀.Name = "타이틀";
            this.타이틀.Size = new System.Drawing.Size(130, 40);
            this.타이틀.TabIndex = 40;
            this.타이틀.Text = "Title";
            this.타이틀.UseVisualStyleBackColor = false;
            this.타이틀.Click += new System.EventHandler(this.타이틀_Click);
            // 
            // 배송정보수정
            // 
            this.배송정보수정.BackColor = System.Drawing.Color.Transparent;
            this.배송정보수정.FlatAppearance.BorderSize = 0;
            this.배송정보수정.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.배송정보수정.Font = new System.Drawing.Font("여기어때 잘난체 OTF", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.배송정보수정.Location = new System.Drawing.Point(60, 350);
            this.배송정보수정.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.배송정보수정.Name = "배송정보수정";
            this.배송정보수정.Size = new System.Drawing.Size(130, 40);
            this.배송정보수정.TabIndex = 18;
            this.배송정보수정.Text = "Delivery Update";
            this.배송정보수정.UseVisualStyleBackColor = false;
            this.배송정보수정.Click += new System.EventHandler(this.배송정보수정_Click);
            // 
            // Delivery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::C_TeamProject.Properties.Resources.png_transparent_desktop_1080p_pastel_mobile_phones_color_pastel_miscellaneous_blue_white;
            this.ClientSize = new System.Drawing.Size(900, 620);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.타이틀);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.배송상태);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.결제일);
            this.Controls.Add(this.약품명);
            this.Controls.Add(this.주소);
            this.Controls.Add(this.받는분);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.개인정보수정);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.배송정보수정);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.검색);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Delivery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delivery";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button 검색;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button 개인정보수정;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label 결제일;
        private System.Windows.Forms.Label 약품명;
        private System.Windows.Forms.Label 주소;
        private System.Windows.Forms.Label 받는분;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label 배송상태;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button 타이틀;
        private System.Windows.Forms.Button 배송정보수정;
    }
}