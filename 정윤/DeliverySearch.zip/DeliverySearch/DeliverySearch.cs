﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_TeamProject
{
    public partial class Delivery : Form
    {
        public Delivery()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Hide();
            new Title().ShowDialog();
        }

        private void 검색_Click(object sender, EventArgs e)
        {
            Hide();
            new Search().ShowDialog();
        }

        private void 개인정보수정_Click(object sender, EventArgs e)
        {
            Hide();
            new MyInfoUpdate().ShowDialog();
        }

        private void 배송정보수정_Click(object sender, EventArgs e)
        {
            Hide();
            new DeliveryUpdate().ShowDialog();
        }

        private void 배송정보조회_Click(object sender, EventArgs e)
        {
            Hide();
            new Delivery().ShowDialog();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.mfds.go.kr/index.do");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 타이틀_Click(object sender, EventArgs e)
        {
            Hide();
            new Title().ShowDialog();
        }
    }
}
